from ._reporty import *
from os import path

templates_dir = path.join(path.dirname(__file__), 'templates')
